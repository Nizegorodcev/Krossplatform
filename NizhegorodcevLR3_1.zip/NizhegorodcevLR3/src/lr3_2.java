import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class lr3_2  extends JFrame{
    private JPanel Mpanel;
    private JLabel label1;
    private JTextField textField1;
    private JButton запускПрограммыButton;
    private JTextField textField2;
    private JTextField textField3;
    static  boolean help_task32(String[] strings,String value,int count){
        boolean flag=true;
        for(int k=0;k<count;k++){
            if(strings[k].length()>value.length()){
                flag=false;
            }
        }
        return flag;
    }
    static String[] task32(final int[] array,int A){

        int first=0;
        String result="";
        int count=0;
        int index=0;
        int c=0;
        String[] strings = new String[array.length];
        int[] array2 = new int[array.length];
        boolean flag=false;
        boolean fl2=true;
        for(int i=first;i<array.length;i++){
            if(i==array.length-1){
                for(int k=0;k<c;k++){

                    if(Math.abs(array2[k]-array[i])<=A){
                        continue;
                    }
                    else{
                        fl2=false;
                        if(k!=c-1){
                            i=first+1;
                        }
                        break;
                    }

                }
                if(fl2==true){
                    array2[c]=array[i];
                    result=result+array[i];
                    c+=1;
                    if(i== array.length-1){
                        boolean fl3=help_task32(strings,result,count);
                        if(fl3==true){
                            strings[count]=result;
                            result="";
                            array2=null;
                            array2 = new int[array.length];
                            flag=false;
                            fl2=true;
                            c=0;
                            count++;
                            i=first+1;
                        }
                        else{
                            result="";
                            array2=null;
                            array2 = new int[array.length];
                            flag=false;
                            fl2=true;
                            c=0;
                            i=first+1;
                        }

                    }

                }
                else{
                    if(result!=""){
                        boolean fl3=help_task32(strings,result,count);
                        if(fl3==true){
                            strings[count]=result;
                            result="";
                            array2=null;
                            array2 = new int[array.length];
                            flag=false;
                            fl2=true;
                            c=0;
                            count++;
                        }
                        else{
                            result="";
                            array2=null;
                            array2 = new int[array.length];
                            flag=false;
                            fl2=true;
                            c=0;
                        }

                    }


                }
            }

            if(Math.abs(array[i]-array[i+1])<=A){
                if(flag==false){
                    array2[c]=array[i];
                    array2[c+1]=array[i+1];
                    result=result+array[i]+array[i+1];
                    first=i;
                    flag=true;
                    c+=2;
                    i+=1;

                }
                else{
                    //fl2=help_task32(array2,array[i],array[i+1],A,c);
                    for(int k=0;k<c;k++){

                        if(Math.abs(array2[k]-array[i])<=A){
                            continue;
                        }
                        else{
                            fl2=false;
                            if(k!=c-1){
                                i=first;
                            }
                            break;
                        }
                    }
                    if(fl2==true){
                        array2[c]=array[i];
                        result=result+array[i];
                        c+=1;

                    }
                    else{
                        if(result!=""){
                            boolean fl3=help_task32(strings,result,count);
                            if(fl3==true){
                                strings[count]=result;
                                result="";
                                array2=null;
                                array2 = new int[array.length];
                                flag=false;
                                fl2=true;
                                c=0;
                                count++;
                            }
                            else{
                                result="";
                                array2=null;
                                array2 = new int[array.length];
                                flag=false;
                                fl2=true;
                                c=0;
                            }

                        }


                    }


                }

            }
            else {
                for(int k=0;k<c;k++){

                    if(Math.abs(array2[k]-array[i])<=A){
                        continue;
                    }
                    else{
                        fl2=false;
                        if(k!=c-1){
                            i=first;
                        }
                        break;
                    }
                }
                if(fl2==true){
                    array2[c]=array[i];
                    result=result+array[i];
                    c+=1;

                }
                else{
                    if(result!=""){
                        boolean fl3=help_task32(strings,result,count);
                        if(fl3==true){
                            strings[count]=result;
                            result="";
                            array2=null;
                            array2 = new int[array.length];
                            flag=false;
                            fl2=true;
                            c=0;
                            count++;
                        }
                        else{
                            result="";
                            array2=null;
                            array2 = new int[array.length];
                            flag=false;
                            fl2=true;
                            c=0;
                        }

                    }


                }
            }
        }
       return strings;
    }


    public lr3_2(){
        setContentPane(Mpanel);
        setTitle("ЛР3.2");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(500,300);
        setLocationRelativeTo(null);
        setVisible(true);
        запускПрограммыButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int A= Integer.parseInt(textField2.getText());
                String str = textField1.getText();
                String d=" ";
                String[] sr =str.split(d);
                int[] array = new int[sr.length];
                for(int i =0;i<sr.length;i++){
                    array[i]=Integer.parseInt(sr[i]);
                }
                String[] sr1 = task32(array,A);
                for(int i=0;i<sr1.length;i++){
                    if(sr[i]!=null){
                        if(sr.length>1){
                            textField3.setText(sr1[1]+" ");
                        }
                        else{
                            textField3.setText(sr1[0]+" ");
                        }
                    }


                }
            }
        });
    }

    public static void main(String[] args) {
        new lr3_2();

    }
}
