import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class LR3  extends  JFrame{

    private JLabel JLabel1;
    private JButton Запуск;
    private JPanel Mainpanel;
    private JTextField textField1;
    static  boolean help_task32(String[] strings,String value,int count){
        boolean flag=true;
        for(int k=0;k<count;k++){
            if(strings[k].length()>value.length()){
                flag=false;
            }
        }
        return flag;
    }
    static void task32(final int[] array,int A){

        int first=0;
        String result="";
        int count=0;
        int index=0;
        int c=0;
        String[] strings = new String[array.length];
        int[] array2 = new int[array.length];
        boolean flag=false;
        boolean fl2=true;
        for(int i=first;i<array.length;i++){
            if(i==array.length-1){
                for(int k=0;k<c;k++){

                    if(Math.abs(array2[k]-array[i])<=A){
                        continue;
                    }
                    else{
                        fl2=false;
                        if(k!=c-1){
                            i=first+1;
                        }
                        break;
                    }

                }
                if(fl2==true){
                    array2[c]=array[i];
                    result=result+array[i];
                    c+=1;
                    if(i== array.length-1){
                        boolean fl3=help_task32(strings,result,count);
                        if(fl3==true){
                            strings[count]=result;
                            result="";
                            array2=null;
                            array2 = new int[array.length];
                            flag=false;
                            fl2=true;
                            c=0;
                            count++;
                            i=first+1;
                        }
                        else{
                            result="";
                            array2=null;
                            array2 = new int[array.length];
                            flag=false;
                            fl2=true;
                            c=0;
                            i=first+1;
                        }

                    }

                }
                else{
                    if(result!=""){
                        boolean fl3=help_task32(strings,result,count);
                        if(fl3==true){
                            strings[count]=result;
                            result="";
                            array2=null;
                            array2 = new int[array.length];
                            flag=false;
                            fl2=true;
                            c=0;
                            count++;
                        }
                        else{
                            result="";
                            array2=null;
                            array2 = new int[array.length];
                            flag=false;
                            fl2=true;
                            c=0;
                        }

                    }


                }
            }

            if(Math.abs(array[i]-array[i+1])<=A){
                if(flag==false){
                    array2[c]=array[i];
                    array2[c+1]=array[i+1];
                    result=result+array[i]+array[i+1];
                    first=i;
                    flag=true;
                    c+=2;
                    i+=1;

                }
                else{
                    //fl2=help_task32(array2,array[i],array[i+1],A,c);
                    for(int k=0;k<c;k++){

                        if(Math.abs(array2[k]-array[i])<=A){
                            continue;
                        }
                        else{
                            fl2=false;
                            if(k!=c-1){
                                i=first;
                            }
                            break;
                        }
                    }
                    if(fl2==true){
                        array2[c]=array[i];
                        result=result+array[i];
                        c+=1;

                    }
                    else{
                        if(result!=""){
                            boolean fl3=help_task32(strings,result,count);
                            if(fl3==true){
                                strings[count]=result;
                                result="";
                                array2=null;
                                array2 = new int[array.length];
                                flag=false;
                                fl2=true;
                                c=0;
                                count++;
                            }

                        }


                    }


                }

            }

        }
        for(int i=0;i<strings.length;i++){
            if(strings[i]!=null){
                System.out.println(strings[i]);
            }

        }
    }
    public static int[] getLongest(final int[] array) {
        int posAux = 0;
        int lonAux = 0;

        int pos = 0;
        int lon = 0;

        int others = 0;

        boolean inSame = false;

        int idx = 0;

        while (idx < (array.length - 1)) {
            if (!inSame) {
                if (array[idx] == array[idx + 1]) {
                    inSame = true;
                    posAux = idx;
                    lonAux = 2;
                    idx++;

                    if (posAux > 0) {
                        posAux--;
                        lonAux++;
                        others++;
                    }
                } else {
                    idx++;
                }
            } else {
                if (array[idx] == array[idx + 1]) {
                    lonAux++;
                    idx++;
                } else {
                    if (others == 2) {
                        if (lon < lonAux) {
                            pos = posAux;
                            lon = lonAux;
                        }

                        inSame = false;
                        posAux = 0;
                        lonAux = 0;
                        others = 0;
                        idx++;
                    } else {
                        others++;

                        if ((idx < (array.length - 2)) && (array[idx] == array[idx + 2])) {
                            lonAux += 2;
                            idx += 2;
                        } else {
                            lonAux++;

                            if (lon < lonAux) {
                                pos = posAux;
                                lon = lonAux;
                            }

                            inSame = false;
                            posAux = 0;
                            lonAux = 0;
                            others = 0;
                            idx++;
                        }
                    }
                }
            }
        }
        return new int[]{pos, lon};
    }
    public LR3(){
        setContentPane(Mainpanel);
        setTitle("ЛР3");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(500,300);
        setLocationRelativeTo(null);
        setVisible(true);
        Запуск.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String str = textField1.getText();
                String d=" ";
                String[] sr =str.split(d);
                int[] array = new int[sr.length];
                for(int i =0;i<sr.length;i++){
                    array[i]=Integer.parseInt(sr[i]);
                }
                int[] coor1 = getLongest(array);


                String str1="";
                for (int i = coor1[0]; i < (coor1[0] + coor1[1]); i++) {
                    str1=str1+array[i];
                }
                JOptionPane.showMessageDialog(LR3.this,"Результат: "+str1+" ");
            }
        });
    }

    public static void main(String[] args) {
        new LR3();

    }
}
